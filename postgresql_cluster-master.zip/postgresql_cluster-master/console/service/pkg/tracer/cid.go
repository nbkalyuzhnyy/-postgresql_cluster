package tracer

type CtxCidKey struct{}
