package xdocker

const (
	playbookCreateCluster = "deploy_pgcluster.yml"

	entryPoint = "ansible-playbook"
)
