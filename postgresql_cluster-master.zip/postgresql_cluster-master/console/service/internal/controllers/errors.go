package controllers

const (
	BaseError = int64(100)
)
