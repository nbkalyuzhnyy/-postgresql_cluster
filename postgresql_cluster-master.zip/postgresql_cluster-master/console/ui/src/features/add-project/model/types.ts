import { PROJECT_FORM_NAMES } from '@features/add-project/model/constants.ts';

export interface ProjectFormValues {
  [PROJECT_FORM_NAMES.NAME]: string;
  [PROJECT_FORM_NAMES.NAME]: string;
}
