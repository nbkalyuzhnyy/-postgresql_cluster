export const PROJECT_FORM_NAMES = Object.freeze({
  NAME: 'name',
  DESCRIPTION: 'description',
});
