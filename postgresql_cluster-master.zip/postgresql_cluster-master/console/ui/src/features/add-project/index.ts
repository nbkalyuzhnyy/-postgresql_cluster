import AddProject from '@features/add-project/ui';

export default AddProject;
