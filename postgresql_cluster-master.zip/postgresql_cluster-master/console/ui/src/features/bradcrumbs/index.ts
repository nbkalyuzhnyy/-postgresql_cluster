import Breadcrumbs from '@/features/bradcrumbs/ui';

export default Breadcrumbs;
