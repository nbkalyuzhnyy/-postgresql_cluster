import ClustersTableRowActions from '@features/clusters-table-row-actions/ui';

export default ClustersTableRowActions;
