export interface ClustersTableRemoveButtonProps {
  clusterId: number;
  clusterName: string;
  closeMenu: () => void;
}
