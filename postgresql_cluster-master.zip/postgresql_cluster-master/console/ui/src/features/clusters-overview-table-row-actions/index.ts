import ClustersOverviewTableRowActions from '@features/clusters-overview-table-row-actions/ui';

export default ClustersOverviewTableRowActions;
