import SettingsTableRowActions from '@features/settings-table-row-actions/ui';

export default SettingsTableRowActions;
