import OperationsTableRowActions from '@features/operations-table-row-actions/ui';

export default OperationsTableRowActions;
