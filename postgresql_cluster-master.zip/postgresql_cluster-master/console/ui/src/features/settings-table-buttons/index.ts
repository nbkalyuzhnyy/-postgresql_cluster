import SettingsTableButtons from '@features/settings-table-buttons/ui';

export default SettingsTableButtons;
