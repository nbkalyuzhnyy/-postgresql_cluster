import LogoutButton from '@features/logout-button/ui';

export default LogoutButton;
