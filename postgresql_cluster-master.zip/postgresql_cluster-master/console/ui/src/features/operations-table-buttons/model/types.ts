export interface OperationsTableButtonsProps {
  refetch: () => void;
  startDate: Date;
  setStartDate: (date: Date) => void;
}
