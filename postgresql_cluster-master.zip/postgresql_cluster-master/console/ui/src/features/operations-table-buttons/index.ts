import OperationsTableButtons from '@features/operations-table-buttons/ui';

export default OperationsTableButtons;
