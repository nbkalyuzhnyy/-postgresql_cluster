import ProjectsTableRowActions from '@features/pojects-table-row-actions/ui';

export default ProjectsTableRowActions;
