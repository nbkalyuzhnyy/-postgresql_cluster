import ClusterSecretModal from '@features/cluster-secret-modal/ui';

export default ClusterSecretModal;
