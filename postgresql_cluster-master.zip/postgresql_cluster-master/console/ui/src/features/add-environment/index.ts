import AddEnvironment from '@features/add-environment/ui';

export default AddEnvironment;
