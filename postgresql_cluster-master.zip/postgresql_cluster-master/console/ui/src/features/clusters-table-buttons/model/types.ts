export interface ClustersTableButtonsProps {
  refetch: () => void;
}
