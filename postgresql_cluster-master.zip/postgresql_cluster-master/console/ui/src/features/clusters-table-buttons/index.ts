import ClustersTableButtons from '@features/clusters-table-buttons/ui';

export default ClustersTableButtons;
