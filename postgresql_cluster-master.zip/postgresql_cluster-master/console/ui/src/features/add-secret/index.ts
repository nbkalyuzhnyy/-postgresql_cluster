import SettingsAddSecret from '@features/add-secret/ui';

export default SettingsAddSecret;
