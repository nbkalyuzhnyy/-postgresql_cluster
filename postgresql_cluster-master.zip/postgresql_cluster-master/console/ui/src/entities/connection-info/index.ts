import ConnectionInfo from '@entities/connection-info/ui';

export default ConnectionInfo;
