import ClusterNameDescriptionBlock from '@entities/cluster-name-description-block/ui';

export default ClusterNameDescriptionBlock;
