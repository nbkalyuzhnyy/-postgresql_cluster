import ClusterDescriptionBlock from '@entities/cluster-description-block/ui';

export default ClusterDescriptionBlock;
