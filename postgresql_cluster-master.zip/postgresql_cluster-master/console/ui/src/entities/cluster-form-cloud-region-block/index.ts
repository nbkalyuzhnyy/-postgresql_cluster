import CloudFormRegionBlock from '@entities/cluster-form-cloud-region-block/ui';

export default CloudFormRegionBlock;
