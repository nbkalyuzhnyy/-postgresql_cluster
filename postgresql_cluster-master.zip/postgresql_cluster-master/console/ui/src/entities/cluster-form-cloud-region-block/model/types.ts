import { DeploymentInfoCloudRegion } from '@shared/api/api/other.ts';

export interface CloudFormRegionBlockProps {
  regions: DeploymentInfoCloudRegion[];
}
