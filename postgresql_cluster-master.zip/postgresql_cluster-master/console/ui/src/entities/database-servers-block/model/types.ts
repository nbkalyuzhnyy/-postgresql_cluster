import { UseFieldArrayRemove } from 'react-hook-form';

export interface DatabaseServerBlockProps {
  index: number;
  remove?: UseFieldArrayRemove;
}
