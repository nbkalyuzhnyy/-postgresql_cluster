import DatabaseServersBlock from '@entities/database-servers-block/ui';

export default DatabaseServersBlock;
