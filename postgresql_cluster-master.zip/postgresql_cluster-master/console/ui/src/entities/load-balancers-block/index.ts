import LoadBalancersBlock from '@entities/load-balancers-block/ui';

export default LoadBalancersBlock;
