export interface ClusterInfoProps {
  postgresVersion?: number;
  clusterName?: string;
  description?: string;
  environment?: string;
  location?: string;
}
