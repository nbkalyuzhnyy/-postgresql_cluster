import ClusterInfo from '@entities/cluster-info/ui';

export default ClusterInfo;
