import SettingsProxyBlock from '@entities/settings-proxy-block/ui';

export default SettingsProxyBlock;
