export const SETTINGS_FORM_FIELDS_NAMES = Object.freeze({
  HTTP_PROXY: 'http_proxy',
  HTTPS_PROXY: 'https_proxy',
});
