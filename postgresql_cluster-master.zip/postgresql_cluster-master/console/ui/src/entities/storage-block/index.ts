import StorageBlock from '@entities/storage-block/ui';

export default StorageBlock;
