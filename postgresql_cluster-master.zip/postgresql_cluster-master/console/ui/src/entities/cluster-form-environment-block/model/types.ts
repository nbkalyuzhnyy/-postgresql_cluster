import { ResponseEnvironment } from '@shared/api/api/environments.ts';

export interface EnvironmentBlockProps {
  environments: ResponseEnvironment[];
}
