import ClusterFormEnvironmentBlock from '@entities/cluster-form-environment-block/ui';

export default ClusterFormEnvironmentBlock;
