import InstancesAmountBlock from '@entities/cluster-form-instances-amount-block/ui';

export default InstancesAmountBlock;
