import ClusterFromInstanceConfigBox from '@entities/cluster-instance-config-box/ui';

export default ClusterFromInstanceConfigBox;
