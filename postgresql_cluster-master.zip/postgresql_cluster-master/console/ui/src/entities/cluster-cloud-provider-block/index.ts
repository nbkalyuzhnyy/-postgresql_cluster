import ClusterFormCloudProviderBox from '@entities/cluster-cloud-provider-block/ui';

export default ClusterFormCloudProviderBox;
