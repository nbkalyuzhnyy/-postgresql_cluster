import { ReactElement } from 'react';

export interface ClusterFormCloudProviderBoxProps {
  children?: ReactElement;
  isActive?: boolean;
}
