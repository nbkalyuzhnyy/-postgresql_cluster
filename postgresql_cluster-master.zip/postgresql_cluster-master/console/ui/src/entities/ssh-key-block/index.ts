import ClusterFormSshKeyBlock from '@entities/ssh-key-block/ui';

export default ClusterFormSshKeyBlock;
