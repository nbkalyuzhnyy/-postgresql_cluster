import ClusterFormClusterNameBlock from '@entities/cluster-form-cluster-name-block/ui';

export default ClusterFormClusterNameBlock;
