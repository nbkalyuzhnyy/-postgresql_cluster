export interface BreadcrumbsItemProps {
  label: string;
  path: string;
}
