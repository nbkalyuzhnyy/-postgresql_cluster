import BreadcrumbsItem from '@entities/breadcumb-item/ui';

export default BreadcrumbsItem;
