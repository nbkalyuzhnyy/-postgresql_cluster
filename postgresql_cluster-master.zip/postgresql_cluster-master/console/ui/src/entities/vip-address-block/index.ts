import VipAddressBlock from '@entities/vip-address-block/ui';

export default VipAddressBlock;
