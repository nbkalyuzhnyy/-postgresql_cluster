import CloudFormInstancesBlock from '@entities/cluster-form-instances-block/ui';

export default CloudFormInstancesBlock;
