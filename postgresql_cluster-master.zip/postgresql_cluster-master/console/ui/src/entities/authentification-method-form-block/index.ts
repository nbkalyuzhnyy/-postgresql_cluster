import AuthenticationMethodFormBlock from '@entities/authentification-method-form-block/ui';

export default AuthenticationMethodFormBlock;
