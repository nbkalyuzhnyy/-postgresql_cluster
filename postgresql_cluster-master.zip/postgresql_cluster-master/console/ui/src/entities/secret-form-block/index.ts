import SecretFormBlock from '@entities/secret-form-block/ui';

export default SecretFormBlock;
