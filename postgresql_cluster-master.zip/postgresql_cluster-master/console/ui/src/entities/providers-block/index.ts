import ClusterFormProvidersBlock from '@entities/providers-block/ui';

export default ClusterFormProvidersBlock;
