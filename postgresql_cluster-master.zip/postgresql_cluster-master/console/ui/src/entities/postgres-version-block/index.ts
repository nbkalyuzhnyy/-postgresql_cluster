import PostgresVersionBox from '@entities/postgres-version-block/ui';

export default PostgresVersionBox;
