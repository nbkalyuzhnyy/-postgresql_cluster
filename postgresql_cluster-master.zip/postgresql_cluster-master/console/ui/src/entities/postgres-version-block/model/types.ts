import { ResponsePostgresVersion } from '@shared/api/api/other.ts';

export interface PostgresVersionBlockProps {
  postgresVersions: ResponsePostgresVersion[];
}
