import AddCluster from '@pages/add-cluster/ui';

export default AddCluster;
