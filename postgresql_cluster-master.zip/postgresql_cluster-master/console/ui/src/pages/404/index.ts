import Page404 from '@pages/404/ui';

export default Page404;
