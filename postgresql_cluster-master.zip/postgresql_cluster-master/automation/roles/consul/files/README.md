# files

This directory is used for holding temporary files and should be present
in the role even when empty.
